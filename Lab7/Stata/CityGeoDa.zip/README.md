The do file is at 

https://gist.github.com/cmg777/f6b2c56d4d152475221f02f247073a23